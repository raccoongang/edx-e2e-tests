Clazz.declarePackage ("org.jmol.rendersurface");
Clazz.load (["org.jmol.rendersurface.IsosurfaceRenderer"], "org.jmol.rendersurface.LcaoCartoonRenderer", null, function () {
c$ = Clazz.declareType (org.jmol.rendersurface, "LcaoCartoonRenderer", org.jmol.rendersurface.IsosurfaceRenderer);
});
