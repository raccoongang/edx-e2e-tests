Clazz.declarePackage ("org.jmol.rendersurface");
Clazz.load (["org.jmol.rendersurface.IsosurfaceRenderer"], "org.jmol.rendersurface.PmeshRenderer", null, function () {
c$ = Clazz.declareType (org.jmol.rendersurface, "PmeshRenderer", org.jmol.rendersurface.IsosurfaceRenderer);
});
