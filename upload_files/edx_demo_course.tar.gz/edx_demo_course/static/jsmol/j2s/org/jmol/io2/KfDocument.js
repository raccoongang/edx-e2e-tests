Clazz.declarePackage ("org.jmol.io2");
c$ = Clazz.declareType (org.jmol.io2, "KfDocument");
