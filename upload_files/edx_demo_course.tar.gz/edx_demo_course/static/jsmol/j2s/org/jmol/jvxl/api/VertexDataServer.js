Clazz.declarePackage ("org.jmol.jvxl.api");
Clazz.declareInterface (org.jmol.jvxl.api, "VertexDataServer");
