Clazz.declarePackage ("org.jmol.io");
Clazz.load (["java.lang.Enum"], "org.jmol.io.Encoding", null, function () {
c$ = Clazz.declareType (org.jmol.io, "Encoding", Enum);
Clazz.defineEnumConstant (c$, "NONE", 0, []);
Clazz.defineEnumConstant (c$, "UTF8", 1, []);
Clazz.defineEnumConstant (c$, "UTF_16BE", 2, []);
Clazz.defineEnumConstant (c$, "UTF_16LE", 3, []);
Clazz.defineEnumConstant (c$, "UTF_32BE", 4, []);
Clazz.defineEnumConstant (c$, "UTF_32LE", 5, []);
});
